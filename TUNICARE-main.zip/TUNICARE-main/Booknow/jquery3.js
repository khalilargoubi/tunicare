$(function(){
    $('fieldset button').on('click',function(){
            $('.popup').fadeIn();
    });
    $('.po i').on('click',function(){
            $('.popup').fadeOut();
    });
});