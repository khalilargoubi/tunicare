# TUNICARE
Tunicare is a well organized website which cover all your needs about medical issue in Tunisia created with "HTML/CSS/JQUERY/JAVASCRIPT/BOOTSTRAP5/PHP/SQL/MYSQL"
# WHAT ARE WE DOING ?
we are computer engineers at the national school of computer science(ENSI) Tunisia
# PROJECT STRUCTURE
Tunicare is a well organized website which cover all your needs about medical issue. 
In fact , this website contains three parts:
first the hospital part in which you can choose the nearest hospital and take an 
Appointment with the choosen one , the second part is the doctor one in which you can discover all the informations about the nearst doctor and take an
Appointment with them and last but not least the pharmacy part in which you can also search for the nearst pharmacy and order any traitement you need of corse if 
it is available . Finally dont forget to contact us for any request or help . 

