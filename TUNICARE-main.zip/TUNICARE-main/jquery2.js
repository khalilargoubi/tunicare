$(function(){
    $('.back .Doctor').slideDown(2000);
    

});